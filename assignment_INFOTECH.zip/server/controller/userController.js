const asyncHandler = require("express-async-handler");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const User = require("../models/userModel");
const { validationResult } = require("express-validator");

//generate JWT
const genToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: "30d",
  });
};
let success = false;
//to implement signup functionality
exports.registerUser = asyncHandler(async (req, res) => {
  // if there are errors, then just return bad request and the errors
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success, errors: errors.array() });
    }
    const { email, name, password } = req.body;
    //if all the fields are not filled
    if (!email || !password || !name) {
      res.status(400).json({ success, error: "Please fill all the fields!" });
    }
    //check if user register
    const userExists = await User.findOne({ email });
    if (userExists) {
      res.status(400).json({ success, error: "Email ID already exists" });
    }
    //hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    //creating the user
    const user = await User.create({
      email,
      name,
      password: hashedPassword,
    });
    if (user) {
      console.log(user);
      console.log("user registered!");
      success = true;
      res.status(201).json({
        success,
        id: user._id,
        email: user.email,
        name: user.name,
      });
    } else {
      res.status(400).json({ success, error: "Invalid user data" });
    }
  } catch (error) {
    res.status(500).json({ success, error: "Internal server error" });
  }
});

//to implement login functionality
exports.loginUser = asyncHandler(async (req, res) => {
  // if there are errors, then just return bad request and the errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success, errors: errors.array() });
  }
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ success, error: "Please fill all the fields!" });
  }
  const userExists = await User.findOne({ email });
  //check if the user exists and the password matches or not
  if (userExists && (await bcrypt.compare(password, userExists.password))) {
    console.log("Logged in");
    success = true;
    res.status(201).json({
      success,
      id: userExists._id,
      token: genToken(userExists._id),
      message: "Logged in successfully",
    });
  } else {
    res.status(400).json({ success, error: "Invalid credentials" });
  }
});

exports.getUserProfile = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success, errors: errors.array() });
  }
  const id = req.params.id;
  const user = await User.findById(id);
  if (user) {
    success = true;
    res.json({
      success,
      id: user._id,
      email: user.email,
      name: user.name,
    });
  } else {
    res.status(404).json({ success, error: "User not found" });
  }
});

exports.editUserProfile = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success, errors: errors.array() });
  }
  const id = req.params.id;
  const user = await User.findById(id);
  if (!user) {
    res.status(404).json({ success, error: "User not found" });
    return;
  }
  success = true;
  const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.json({
    success,
    updatedUser,
  });
});

exports.changePassword = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { oldPassword, newPassword } = req.body;
  try {
    const oldUser = await User.findById(id);
    if (!oldUser) {
      res.status(404).json({ success, error: "User not found" });
    } else if (
      oldUser &&
      (await bcrypt.compare(oldPassword, oldUser.password))
    ) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(newPassword, salt);
      success = true;
      oldUser.password = hashedPassword;
      await oldUser.save();
      res.status(201).json({
        success,
        id: oldUser._id,
        message: "Password changed successfully",
      });
    } else {
      res.status(400).json({ success, error: "Invalid credentials" });
    }
  } catch (error) {
    res.status(500).json({ success, error: "Internal server error" });
  }
});
