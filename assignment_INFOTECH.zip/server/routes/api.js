const express = require("express");
const router = express.Router();
const { body } = require("express-validator");
const {
  registerUser,
  loginUser,
  getUserProfile,
  editUserProfile,
  changePassword,
} = require("../controller/userController");
const { protect } = require("../middleware/authMiddleware");

router.post(
  "/register",
  [
    body("email", "Enter a valid Email Id").isEmail(),
    body("password", "Password must be of at least 6 characters").isLength({
      min: 6,
    }),
    body("name", "Name must be of at least 3 characters").isLength({ min: 3 }),
  ],
  registerUser
);
router.post(
  "/login",
  [
    body("email", "Enter a valid Email Id").isEmail(),
    body("password", "Password must be of at least 6 characters").isLength({
      min: 6,
    }),
  ],
  loginUser
);
router.get("/profile/:id", protect, getUserProfile);
router.put("/editProfile/:id", protect, editUserProfile);
router.put("/change-password/:id", protect, changePassword);
module.exports = router;