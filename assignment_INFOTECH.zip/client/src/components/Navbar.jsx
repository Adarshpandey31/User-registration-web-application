/*eslint-disable*/
import React from "react";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <nav>
      <div className="flex justify-end pr-3">
        <Link to={"/"} className="hover:bg-slate-300 hover:rounded-md p-3 text-blue-500">
          Profile
        </Link>
        <Link
          to={"/change-password"}
          className="ml-3 hover:bg-slate-300 hover:rounded-md p-3 text-blue-500"
        >
          Change Password
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
