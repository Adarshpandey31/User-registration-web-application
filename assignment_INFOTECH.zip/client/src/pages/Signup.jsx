/*eslint-disable*/
import React, { useEffect } from "react";
import Form from "../components/Form.jsx";
import { useNavigate } from "react-router-dom";

export const Signup = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/");
    } else {
      navigate("/register");
    }
  }, []);
  return (
    <Form name="Sign up" text="Already have an account?" alterName="Sign in" />
  );
};