/*eslint-disable*/
import React, { useEffect } from "react";
import Form from "../components/Form";
import { useNavigate } from "react-router-dom";

export const Login = () => {
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/");
    } else {
      navigate("/login");
    }
  }, []);
  return (
    <Form
      name="Sign in"
      text="Don’t have an account yet?"
      alterName="Sign up"
    />
  );
};
