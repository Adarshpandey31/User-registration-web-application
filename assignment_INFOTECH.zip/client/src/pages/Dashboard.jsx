/*eslint-disable*/
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Loading from "../components/Loading";
import Card from "../components/Card";
import Navbar from "../components/Navbar";

export const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({});
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
    } else {
      navigate("/");
    }
  }, []);
  const getUserProfile = async (id) => {
    try {
      setLoading(true);
      const response = await fetch(
        `http://localhost:8000/api/user/profile/${id}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      const data = await response.json();
      console.log(data);
      if (response.ok) {
        setUser(data);
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    const id = localStorage.getItem("userId");
    if(id)
      getUserProfile(id);
    else
      navigate("/login");
  }, []);
  return (
    <div className="overflow-x-hidden overflow-y-hidden">
      <Navbar/>
      <div className="flex flex-col w-screen items-center justify-center">
        {loading ? <Loading /> : <Card name={user.name} email={user.email} />}
      </div>
    </div>
  );
};
