/*eslint-disable*/
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Navbar from "../components/Navbar";

export const ChangePassword = () => {
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/change-password");
    } else {
      navigate("/login");
    }
  }, []);
  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (confirm !== newPassword) {
      toast.error("Password does not match");
      setNewPassword("");
      setConfirm("");
    } else {
      try {
        const id = localStorage.getItem("userId");
        const response = await fetch(
          `http://localhost:8000/api/user/change-password/${id}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
            body: JSON.stringify({
              oldPassword,
              newPassword,
            }),
          }
        );
        const data = await response.json();
        if (response.ok) {
          toast.success(data.message);
          localStorage.removeItem("token");
          localStorage.removeItem("userId");
          navigate("/login");
        } else {
          throw new Error(data.error);
        }
      } catch (error) {
        toast.error(error.message);
      }
    }
  };
  return (
    <div className="dark:bg-gray-900 w-screen h-screen">
      <Navbar />
      <div className="lg:px-8 flex justify-center items-center">
        <form
          className="space-y-6  w-1/2 px-6 py-6"
          onSubmit={handleChangePassword}
        >
          <h3 className="mb-4 text-xl text-center font-medium text-gray-900 dark:text-white">
            Change Password
          </h3>
          <div>
            <label
              for="old-password"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              Old Password
            </label>
            <input
              type="password"
              name="old-password"
              id="old-password"
              onChange={(e) => setOldPassword(e.target.value)}
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
              placeholder="••••••••"
              required
            />
          </div>
          <div>
            <label
              for="new-password"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              New Password
            </label>
            <input
              type="password"
              name="new-password"
              id="new-password"
              onChange={(e) => setNewPassword(e.target.value)}
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
              placeholder="••••••••"
              required
            />
          </div>
          <div>
            <label
              for="confirm-password"
              className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
              Confirm New Password
            </label>
            <input
              type="password"
              name="new-password"
              id="new-password"
              onChange={(e) => setConfirm(e.target.value)}
              className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white"
              placeholder="••••••••"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};
